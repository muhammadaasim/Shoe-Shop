import React from 'react'
import './css/theme.css';

const About = () => {
    return (
        <div className="app">
            <h1>About</h1>
        </div>
    )
}

export default About
