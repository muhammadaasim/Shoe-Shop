import React, { useContext } from 'react';
import { useParams } from 'react-router-dom';
import { GlobalContext } from '../Context/GlobalState'
import './css/theme.css';
import Shoes from '../Context/ShoesData.json';
import { Button } from '@material-ui/core';
const Details = () => {
  let { id } = useParams();
  const Shoe = Shoes[id];
  const { cart, addProduct, incQty } = useContext(GlobalContext);
  const AddProduct = e => {
    e.preventDefault();
    if (cart.map(
      product => (product.id === Shoe ? true : false))
      .includes(true)) {
      incQty(Shoe);
    } 
    else {
      const newProduct = {
        id: Shoe,
        image: Shoe.IMG,
        quantity: 1
      }
      addProduct(newProduct)
    }
  }


  if (!Shoe) {
    return <h2>Product Not Found!</h2>
  }
  return (
    <div className="app">
      {
        <div className="product-card">
          <h1>Product Items</h1>
          <img src={Shoe.IMG} alt={Shoe.NAME} className="product-img" />
          <h4>{Shoe.NAME}</h4>
          <h5>{Shoe.PRICE}</h5>
          <Button variant="contained" color="primary" onClick={AddProduct}>
            Add to Cart
          </Button>
        </div>

      }
    </div>
  )
}

export default Details
