import React,{useContext} from 'react'
import Shoes from '../Context/ShoesData.json';
import { Link } from 'react-router-dom';
// import {GlobalContext} from '../Context/GlobalState'
import './css/theme.css'
import { Button } from '@material-ui/core';
const Products = () => {

    return (
        <div className="app">
            <h1>Products</h1>
            <div className="product-container">
                {
                    Object.keys(Shoes).map(KeyName => {
                        const Shoe = Shoes[KeyName];
                        return (
                            <div className="product-card">
                                <Link to={`/details/${KeyName}`}>
                                    <img src={Shoe.IMG} alt={Shoe.NAME} className="product-img" />
                                    <h4>{Shoe.NAME}</h4>
                                    <h3>{Shoe.PRICE}</h3>
                                </Link>
                                <Button variant="contained" color="primary">
                                    Add to Cart
                                </Button>
                            </div>
                        )
                    }
                    )
                }
            </div>
        </div>
    )
}

export default Products;