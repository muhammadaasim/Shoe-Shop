import React from 'react';
import './App.css';
import RouteConfig from './RouteConfig';
function App() {
  return (
 <div>
   <RouteConfig/>
 </div>
  );
}

export default App;
