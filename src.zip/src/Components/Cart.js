import React from 'react'
import './css/theme.css'
const Cart = () => {
    return (
        <div class="app">
              <h1>Cart</h1>
        </div>
    )
}

export default Cart
    