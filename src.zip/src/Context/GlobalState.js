import React, { createContext, useReducer } from 'react';
import AppReducer from './AppReducer';


// Initial state

const initialState = {
    cart: []
};

// create context

export const GlobalContext = createContext(initialState);


// provider compnent

export const GlobalProvider = ({ children }) => {
    const [state, dispatch] = useReducer(AppReducer, initialState);


    function addProduct(product){
        dispatch({
            type: 'ADD_PRODUCT',
            payload: product
        });
    }

    function incQty(id){
        dispatch({
            type: 'INC_QTY',
            payload: id
        });
    }

    function decQty(id){
        dispatch({
            type: 'DEC_QTY',
            payload: id
        });
    }
    function deleteProduct(id){
        dispatch({
            type: 'DELETE',
            payload: id
        });
    }

    return (
        <GlobalContext.Provider value={{ 
            cart: state.cart,
            addProduct,
            incQty,
            decQty,
            deleteProduct,
             }}>
            {children}
        </GlobalContext.Provider>
    );
}