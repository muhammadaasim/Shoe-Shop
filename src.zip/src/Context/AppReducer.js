export default (state, action) => {
    switch (action.type) {
        case 'ADD_PRODUCT':
            return {
                ...state,
                cart: [action.payload, ...state.cart]
            }
        case 'INC_QTY':
            state.cart.map(product => (product.id === action.payload ? (product.quantity += 1, true) : false))
            return {
                ...state,
                cart: state.cart
            }
        case 'DEC_QTY':
            state.cart.map(product =>
                (product.id === action.payload ?
                    (product.quantity <= 1 ? product.quantity : product.quantity -= 1, true) : false)
            )
            break;
        case 'DELETE':
            return {
                ...state,
                cart: state.cart.filter(product => product.id !== action.payload)
            }
            
        default:
            return state;
    }
}